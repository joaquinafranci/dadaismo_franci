<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Formulario de Login</title>
</head>

<body>
	<h2>Logueate</h2>
	<form action="login.php" method="post">
    	<label>Nombre de usuario
        	<input name="usuario" type="text" maxlength="12" />
        </label><br />
        <label>Contraseña
        	<input type="password" name="password" maxlength="12" />
        </label><br />
        	<input type="submit" value="Login"/>	
    </form>
    <a href="index.html">Registrate</a> si no sos usuario.
    


</body>
</html>